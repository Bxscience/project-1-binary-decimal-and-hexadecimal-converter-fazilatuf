package com.example.nazrulhaque.convertor;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText dec;
    private EditText bin;
    private EditText hex;
    private Button conv;
    private Button clear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dec = (EditText) findViewById(R.id.dec);
        bin = (EditText) findViewById(R.id.bin);
        hex = (EditText) findViewById(R.id.hex);
        conv = (Button) findViewById(R.id.conv);
        clear = (Button) findViewById(R.id.clear);

    //Decimal
    dec.addTextChangedListener(new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if(dec.getText().length()>0){
                bin.setEnabled(false);
                hex.setEnabled(false);
            }
            else{
                bin.setEnabled(true);
                hex.setEnabled(true);
            }

        }
        @Override
        public void afterTextChanged(Editable editable) {

        }

    });

    //Bin
    bin.addTextChangedListener(new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if(bin.getText().length()>0){
                hex.setEnabled(false);
                dec.setEnabled(false);
            }
            else{
                hex.setEnabled(true);
                dec.setEnabled(true);
            }

        }
        @Override
        public void afterTextChanged(Editable editable) {

        }

    });

    //Hex
    hex.addTextChangedListener(new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if(hex.getText().length()>0){
                bin.setEnabled(false);
                dec.setEnabled(false);
            }
            else{
                bin.setEnabled(true);
                dec.setEnabled(true);
            }

        }
        @Override
        public void afterTextChanged(Editable editable) {

        }

    });

    //Convert
    conv.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            if(dec.getText().length()>0){
                //dec to bin
                /*Toast toast = Toast.makeText(MainActivity.this, "Enter both numbers please!", Toast.LENGTH_LONG);
                toast.show();*/
                try{
                    Integer.parseInt(dec.getText().toString());
                }
                catch(NumberFormatException e){
                    Toast toast = Toast.makeText(MainActivity.this, "Enter valid DECIMAL number", Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }
                String decBin = Integer.toBinaryString(Integer.parseInt(dec.getText().toString()));
                bin.setText(decBin);

                //dec to hex
                String decHex = Integer.toHexString(Integer.parseInt(dec.getText().toString()));
                hex.setText(decHex);

            }
            else if(bin.getText().length()>0){
                try{
                    Integer.parseInt(bin.getText().toString(),2);
                }
                catch(NumberFormatException e){
                    Toast toast = Toast.makeText(MainActivity.this, "Enter valid BINARY number", Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }
                //bin to dec
                int binDec = Integer.parseInt(bin.getText().toString(),2);
                dec.setText(String.valueOf(binDec));

                //bin to hex
                String binHex = Integer.toHexString(Integer.parseInt(String.valueOf(binDec)));
                hex.setText(binHex);
            }
            else{
                //hex to dec
                try{
                    Long.parseLong(hex.getText().toString(),16);
                }
                catch(NumberFormatException e){
                    Toast toast = Toast.makeText(MainActivity.this, "Enter valid HEX number", Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }
                int hexDec = (int) Long.parseLong(hex.getText().toString(), 16);
                dec.setText(String.valueOf(hexDec));

                //hex to bin
                String hexBin = Integer.toBinaryString(Integer.parseInt(String.valueOf(hexDec)));
                bin.setText(hexBin);

            }

        }
    });

    clear.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            dec.setText("");
            bin.setText("");
            hex.setText("");
            dec.setEnabled(true);
            bin.setEnabled(true);
            hex.setEnabled(true);
        }
    });

    }
}
